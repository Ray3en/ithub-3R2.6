import Button from "./components/UI/Button/Buton";

function App() {
  return (
    <div>
       <Button 
        title='Serach now'
        theme='light'
      />
       <Button 
        onClick={() => console.log('click')}  
        title='Get'
        theme='dark'
      />
    </div>
  );
}

export default App;
